import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Register from './component/Register'
import Login from './component/Login'
import Dashboard from './component/Dashboard'

const App = () => {
  return (
    <>

      <Routes>

        <Route path='/' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/home' element={<Dashboard />} />
      </Routes >

    </>
  )
}

export default App