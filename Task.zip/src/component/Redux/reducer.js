import { walletBalance } from './constant'


const currentBalance = 0


export const reducer = (state = currentBalance, action) => {

    switch (action.type) {

        case walletBalance:
            return state = action.payload


        default:
            return state


    }

}

