import { walletBalance } from './constant'


export function Wallet(action) {


    return {
        type: walletBalance,
        payload: action

    }

}