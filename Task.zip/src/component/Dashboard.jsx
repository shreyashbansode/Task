import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { BiSolidUserCircle } from 'react-icons/bi'
import { Wallet } from './Redux/action'
const Dashboard = () => {


    const data = useSelector(state => state.reducer)


    const dispatch = useDispatch();

    const [userData, setuserData] = useState()

    console.log(userData, 'userData')    // user Data are shown in console !!!

    const [walletValue, setwalletValue] = useState(0)
    const [visible, setVisible] = useState(false)

    function display() {
        setVisible(!visible)
    }

    const Data = async () => {

        const token = JSON.parse(localStorage.getItem('token'))

        const fetchData = await fetch('http://localhost:5000/user', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                Authorization: token
            }

        })

        const res = await fetchData.json()
        setuserData(res)

    }

    useEffect(() => {
        Data()

    }, [])


    const submitHandler = (e) => {

        e.preventDefault()

        dispatch(Wallet(walletValue))

        // console.log(walletValue, 'wallet value')

    }


    return (
        <>
            <section>
                <div className="user">
                    <div className="nested-user">
                        <div className="icon">
                            <BiSolidUserCircle size={60} />
                        </div>
                        <div className="wallet">
                            <h3>₹ {data}</h3>
                            {
                                !visible ? <button onClick={() => display()}>Top up</button> : <button onClick={() => display()}>Close</button>
                            }
                        </div>

                        {
                            visible && (
                                <>
                                    <form action="" onSubmit={submitHandler}>
                                        <div className='amount-bx'>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Enter Amount : </label>
                                                <input type="number" class="form-control" aria-describedby="emailHelp" required onChange={(e) => setwalletValue(e.target.value)} value={walletValue} />

                                            </div>
                                            <div className='wallet'>
                                                <button type='submit'  >Add Amount</button>
                                            </div>
                                        </div>
                                    </form>
                                </>

                            )
                        }
                    </div>
                </div>
            </section>
        </>
    )
}

export default Dashboard