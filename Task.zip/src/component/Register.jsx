import React, { useEffect, useState } from 'react'
import "./style.css"
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { AiOutlineInfoCircle } from 'react-icons/ai';

const Login = () => {

    const [userData, setuserData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: ''
    });

    const [nameError, setnameError] = useState(false)
    const [lastNameError, setlastNameError] = useState(false);
    const [emailError, setemailError] = useState(false)
    const [passwordError, setpasswordError] = useState(false)




    const handleChange = (e) => {

        const { name, value } = e.target

        setuserData({
            ...userData, [name]: value
        })




    }



    const navigate = useNavigate();



    const submitHandler = async (e) => {
        e.preventDefault()


        const { firstName, lastName, email, password } = userData;





        if (!userData.firstName) {
            setnameError(true)
        }
        else {
            setnameError(false)
        }
        if (!userData.lastName) {
            setlastNameError(true)
        }
        else {
            setlastNameError(false)
        }

        if (!userData.password) {
            setpasswordError(true)
        }
        else {
            setpasswordError(false)
        }

        let re = /\s+@\s+\.s+/;
        let regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

        if (re.test(email) || regex.test(email)) {
            setemailError(false)
        } else {
            setemailError(true)
        }


        if (!userData.firstName || !userData.lastName || !userData.email || !userData.password) {
            return false
        }

        const data = await fetch('http://localhost:5000/', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                firstName, lastName, email, password
            })

        })


        const res = await data.json()

        if (res) {
            toast.success('Register Successfully', { position: 'bottom-right' })
        }

        setTimeout(() => {
            navigate('/login')

        }, 2000)


    }


    return (
        <>
            <section>
                <div className="loginbx">


                    <div className="logincontainer">
                        <div className='nested-login-container'>
                            <div className="loginimg">

                                <h4> Register</h4>
                            </div>
                            <form onSubmit={submitHandler}>



                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">First Name :</label>
                                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="name" name='firstName' onChange={handleChange} />
                                    {
                                        nameError && (<>
                                            <div style={{
                                                marginTop: '10px',
                                                width: '100%',
                                                display: 'flex',
                                                justifyContent: 'end',
                                                alignItems: 'center'

                                            }}>
                                                <AiOutlineInfoCircle color='red' />
                                                <span style={{ color: 'red', marginLeft: '5px' }}>Required</span>
                                            </div>
                                        </>)
                                    }
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Last Name:</label>
                                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="last name" name='lastName' onChange={handleChange} />
                                    {
                                        lastNameError && (<>
                                            <div style={{
                                                marginTop: '10px',
                                                width: '100%',
                                                display: 'flex',
                                                justifyContent: 'end',
                                                alignItems: 'center'

                                            }}>
                                                <AiOutlineInfoCircle color='red' />
                                                <span style={{ color: 'red', marginLeft: '5px' }}>Required</span>
                                            </div>
                                        </>)
                                    }
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Email address :</label>
                                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" name='email' onChange={handleChange} />

                                    {
                                        emailError && (<>
                                            <div style={{
                                                marginTop: '10px',
                                                width: '100%',
                                                display: 'flex',
                                                justifyContent: 'end',
                                                alignItems: 'center'

                                            }}>
                                                <AiOutlineInfoCircle color='red' />
                                                <span style={{ color: 'red', marginLeft: '5px' }}>Required</span>
                                            </div>
                                        </>)
                                    }
                                </div>
                                <div class="mb-3">
                                    <label for="inputPassword5" class="form-label">Password :</label>
                                    <input type="password" id="inputPassword5" class="form-control" aria-labelledby="passwordHelpBlock" placeholder='xxxxxx' name='password' onChange={handleChange} />
                                    {
                                        passwordError && (<>
                                            <div style={{
                                                marginTop: '10px',
                                                width: '100%',
                                                display: 'flex',
                                                justifyContent: 'end',
                                                alignItems: 'center'

                                            }}>
                                                <AiOutlineInfoCircle color='red' />
                                                <span style={{ color: 'red', marginLeft: '5px' }}>Required</span>
                                            </div>
                                        </>)
                                    }
                                </div>
                                <div id="passwordHelpBlock" class="form-text">
                                    Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                                </div>
                                <div className="adminlogbtn">
                                    <button type='submit' >Register</button>

                                </div>
                                <div style={{
                                    height: '30px',
                                    width: '90%',
                                    display: 'flex',
                                    justifyContent: 'end',
                                    alignItems: 'center'
                                }}>
                                    <span style={{ fontSize: '12px' }}> Already Register ?<span style={{ color: 'blue', cursor: 'pointer' }} onClick={() => navigate('/login')}> Click here to login</span></span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <ToastContainer />
            </section>

        </>
    )
}

export default Login