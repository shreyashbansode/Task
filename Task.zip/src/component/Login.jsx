import React, { useEffect, useState } from 'react'
import "./style.css"
import axios from 'axios';
import { json, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {

    const [userData, setuserData] = useState({
        email: '',
        password: ''
    });



    const handleChange = (e) => {

        const { name, value } = e.target

        setuserData({
            ...userData, [name]: value
        })




    }




    const navigate = useNavigate();



    const submitHandler = async (e) => {
        e.preventDefault()


        const { email, password } = userData;



        const data = await fetch('http://localhost:5000/login', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email, password
            })

        })


        const res = await data.json()

        console.log(res)

        if (res) {
            localStorage.setItem('token', JSON.stringify(res.token))
            toast.info('login Successfully', { position: 'bottom-right' })

            // console.log(res.token)/

        }

        setTimeout(() => {
            navigate('/home')
        }, 2000);



    }


    return (
        <>
            <section>
                <div className="loginbx">


                    <div className="logincontainer">
                        <div className='nested-login-container'>
                            <div className="loginimg">

                                <h4> Register</h4>
                            </div>
                            <form onSubmit={submitHandler}>

                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Email address :</label>
                                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" name='email' onChange={handleChange} />
                                </div>
                                <div class="mb-3">
                                    <label for="inputPassword5" class="form-label">Password :</label>
                                    <input type="password" id="inputPassword5" class="form-control" aria-labelledby="passwordHelpBlock" placeholder='xxxxxx' name='password' onChange={handleChange} />
                                </div>
                                <div id="passwordHelpBlock" class="form-text">
                                    Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                                </div>
                                <div className="adminlogbtn">
                                    <button type='submit' >Login</button>

                                </div>
                                <div style={{
                                    height: '30px',
                                    width: '90%',
                                    display: 'flex',
                                    justifyContent: 'end',
                                    alignItems: 'center'
                                }}>
                                    <span style={{ fontSize: '12px' }}> New user  ?<span style={{ color: 'blue', cursor: 'pointer' }} onClick={() => navigate('/')}> Click here to Register</span></span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <ToastContainer />
            </section>

        </>
    )
}

export default Login