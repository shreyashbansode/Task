const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const secretkey = "mynameisshreyashbasndodedansas"


const userSchema = new mongoose.Schema({

    firstName: String,
    lastName: String,
    email: String,
    password: String,
    tokens: [{
        token: {
            type: String,
            required: true
        }
    }]



})



userSchema.methods.generateToken = async function () {

    try {

        let token23 = jwt.sign({ _id: this._id }, secretkey, {
            expiresIn: '1d'
        })

        this.tokens = this.tokens.concat({ token: token23 })
        await this.save();
        return token23;
    }
    catch (err) {
        res.json(err)
    }

}



































module.exports = mongoose.model('users', userSchema)