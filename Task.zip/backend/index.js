const express = require('express')

const app = express();
const cors = require('cors')
const conn = require('./db')



conn.connection.on('connected', (err) => {

    if (err) {
        console.log(err)
    }
    else {
        console.log('mongodb is connected')
    }
})
app.use(cors())
app.use(express.json());
app.use('/', require('./route/user'))


app.listen(5000, () => {
    console.log('server is on')
})