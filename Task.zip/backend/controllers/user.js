const model = require('../model/user')



exports.createuser = async (req, res) => {

    // console.log(req.body)
    try {
        const savedData = await new model(req.body).save();
        res.json(savedData)

    }
    catch (err) {
        res.json(err)
    }
}



exports.loginUser = async (req, res) => {

    try {

        const { email, password } = req.body;

        const data = await model.findOne({ email: email, password: password })
        // console.log(data)

        if (data) {
            const token = await data.generateToken();
            // console.log(token);

            const result = {
                data,
                token
            }
            res.json(result)

        }


        // res.status(201).json({status:201,result})


    } catch (err) {
        res.json(err)
    }
}