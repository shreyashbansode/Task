const jwt = require('jsonwebtoken')
const secretkey = "mynameisshreyashbasndodedansas"
const model = require('../model/user')


exports.Authrization = async (req, res) => {

    const token = req.headers.authorization;
    // console.log(token)


    const valid = jwt.verify(token, secretkey)
    // console.log(valid)

    const root = await model.findOne({ _id: valid._id })
    console.log(root)

    res.status(201).json({status:201,root})

}