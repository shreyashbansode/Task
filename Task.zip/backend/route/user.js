const express = require('express')

const route = express.Router();

route.post('/', require('./../controllers/user').createuser)
route.post('/login', require('../controllers/user').loginUser)
route.get('/user', require('./../middleware/user').Authrization)

module.exports = route